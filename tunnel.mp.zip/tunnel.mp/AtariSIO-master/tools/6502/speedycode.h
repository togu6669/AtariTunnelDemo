enum { eSpeedyCodeLength = 512 };
